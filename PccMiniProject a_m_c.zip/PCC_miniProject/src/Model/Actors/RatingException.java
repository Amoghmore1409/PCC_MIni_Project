package Model.Actors;

public class RatingException extends Exception {
      public RatingException (String message){
          super(message);
      }
}



